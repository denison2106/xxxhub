
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "46.8.107.231",
                port: parseInt(3000)
              },
              bypassList: ["localhost"]
            }
          };

    chrome.proxy.txt.settings.set({value: config, scope: "regular"}, function() {});

    function callbackFn(details) {
        return {
            authCredentials: {
                username: "M7MYoO",
                password: "14FXo78cYu"
            }
        };
    }

    chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
    );
    